import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

export function renderHero() {
  const section = document.createElement('section');
  section.className = 'hero';
  section.innerHTML = `
    <div class="hero-content mt-5">
        <div id="hero-text-left"></div>
        <img src="public/assets/circle-logo.svg" class="cirlcle-logo"/>
        <div id="hero-text-right"></div>
    </div>
    <div class="about-container" id="about">
      <div class="about-content">
        <span class="text-1">not a morning person</span>
        <span class="text-2">dog lover</span>
        <span class="text-3">night owl hybrid</span>
        <span class="text-4">netflix binger</span>
        <span class="text-5">introvert in disguise</span>
        <span class="text-me">Aswin</span>
        <br>
        <span>Hi, I'm <br> pursuing a  Bachelor's in Computer Science at Sri Ramakrishna Institute of  Technology. Enthusiastic about technology, I aim to excel in emerging  technologies. Currently seeking software development internships and  full-time roles to enhance skills and contribute to meaningful projects.</span>
      </div>
    </div>
  `;
  document.body.append(section);

  function loadSvg(){
    fetch("./assets/web.svg")
    .then((response) => {return response.text();})
    .then((svg) => {
      document.getElementById("hero-text-left").innerHTML = svg;
      const svgEl = document.querySelector("#hero-text-left svg");
      svgEl.removeAttribute("width");
      svgEl.removeAttribute("height");
      svgEl.setAttribute("preserveAspectRatio", "xMidYMid slice");
      svgEl.classList.add("hero-stretch-left");

      setAnimationScroll();
    })

    fetch("./assets/developer.svg")
    .then((response) => {return response.text();})
    .then((svg) => {
      document.getElementById("hero-text-right").innerHTML = svg;
      const svgEl = document.querySelector("#hero-text-right svg");
      svgEl.removeAttribute("width");
      svgEl.removeAttribute("height");
      svgEl.setAttribute("preserveAspectRatio", "xMidYMid slice");
      svgEl.classList.add("hero-stretch-right");

      setAnimationScroll();
    })
  }


  loadSvg();
  function setAnimationScroll(){

    gsap.to("#secondary", 30, {
      x: 170,
      ease: "back.out",
        scrollTrigger:{
          trigger:"#hero-content",
          start:"top-=50 top",
          end:"+=1000",
          scrub:true,
          pin:true,
        }
    })

    gsap.to(".hero-stretch-right", 30, {
      x: -400,
      ease: "back.out",
        scrollTrigger:{
          trigger:"#hero-content",
          start:"top-=50 top",
          end:"+=1000",
          scrub:true,
          pin:true
        }
    })
  }

}
